# Mahfazati | محفظتي

Android personal-finance application by **M.Z DIGITAL**.

## Current implementation (v1.2.0)

- Arabic RTL Jetpack Compose interface.
- Local Room database with a migration from database version 1 to 2, preserving existing transactions.
- Separate quick actions and dedicated forms for **income** and **expenses**.
- Iraqi-dinar amount entry uses **thousands of dinars** across income, expenses, budgets, debts, repayments, opening balances, and savings goals (for example, entering `25` means `25,000 IQD`). Values continue to be stored internally as whole IQD; existing saved records are not converted or modified.
- Transaction list with search by amount, category, type, and note; delete operation.
- Dashboard balance privacy toggle, current-month income/expense summaries, and a category-by-category monthly expense list.
- Expense categories include food, health, transport, housing, shopping, bills, internet/communications, education, entertainment, personal care, and maintenance. Expense amounts and category breakdown bars are highlighted in red.
- Debt balances and savings-goal totals/progress are highlighted in green, with summary totals shown in the More section.
- Budgets by category and daily, weekly, or monthly period, with progress based on recorded expenses.
- Expense breakdown and cash-flow summaries based only on recorded transactions.
- Debt records for money owed to the user and money the user owes, including partial repayment tracking.
- Multiple account records with opening balances.
- Savings goals with contribution tracking.
- Offline-first local storage; no account registration or financial-data server upload.

## Build

Open the project in Android Studio, or run:

```bash
gradle assembleDebug
```

The GitHub Actions workflow in `.github/workflows/build.yml` expects `Mahfazati.zip` in the repository root, extracts it, builds the debug APK, and uploads the APK as an Actions artifact.

## Important scope notes

This version implements the features listed above. Biometric/PIN app lock, scheduled notifications, currency conversion and exchange-rate updates, full transaction editing, account-to-account transfers, PDF export, and encrypted backup/restore are not yet implemented and should not be treated as available features.

## Branding

Mahfazati | محفظتي  
Developed by M.Z DIGITAL  
© 2026 M.Z DIGITAL. All Rights Reserved.
