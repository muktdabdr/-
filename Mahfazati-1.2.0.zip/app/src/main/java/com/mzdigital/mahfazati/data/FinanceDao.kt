package com.mzdigital.mahfazati.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BudgetDao {
    @Query("SELECT * FROM budgets ORDER BY id DESC") fun observeAll(): Flow<List<Budget>>
    @Insert suspend fun insert(item: Budget)
    @Delete suspend fun delete(item: Budget)
}

@Dao
interface DebtDao {
    @Query("SELECT * FROM debts ORDER BY createdAt DESC") fun observeAll(): Flow<List<Debt>>
    @Insert suspend fun insert(item: Debt)
    @Update suspend fun update(item: Debt)
    @Delete suspend fun delete(item: Debt)
}

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts ORDER BY id") fun observeAll(): Flow<List<WalletAccount>>
    @Insert suspend fun insert(item: WalletAccount)
    @Delete suspend fun delete(item: WalletAccount)
}

@Dao
interface GoalDao {
    @Query("SELECT * FROM goals ORDER BY id DESC") fun observeAll(): Flow<List<SavingsGoal>>
    @Insert suspend fun insert(item: SavingsGoal)
    @Update suspend fun update(item: SavingsGoal)
    @Delete suspend fun delete(item: SavingsGoal)
}
