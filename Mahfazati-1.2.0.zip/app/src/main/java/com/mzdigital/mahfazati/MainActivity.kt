package com.mzdigital.mahfazati

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mzdigital.mahfazati.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Emerald = Color(0xFF087F5B)
private val Pale = Color(0xFFF3F7F5)
private val Ink = Color(0xFF17231E)
private val IncomeGreen = Color(0xFF16865F)
private val ExpenseRed = Color(0xFFD65B5B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val db = AppDatabase.get(this)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Emerald, background = Pale, surface = Color.White, secondary = Color(0xFF65B891))) {
                MahfazatiApp(db)
            }
        }
    }
}

class WalletViewModel(private val db: AppDatabase) : ViewModel() {
    private val txDao = db.transactionDao()
    val transactions = txDao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val balance = txDao.observeBalance().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    val budgets = db.budgetDao().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val debts = db.debtDao().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val accounts = db.accountDao().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val goals = db.goalDao().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addTransaction(amount: Long, type: String, category: String, note: String, account: String = "نقداً") = viewModelScope.launch {
        if (amount > 0) txDao.insert(Transaction(amount = amount, type = type, category = category, note = note, account = account))
    }
    fun deleteTransaction(item: Transaction) = viewModelScope.launch { txDao.delete(item) }
    fun addBudget(name: String, category: String, amount: Long, period: String) = viewModelScope.launch { if (amount > 0) db.budgetDao().insert(Budget(name = name, category = category, amount = amount, period = period)) }
    fun deleteBudget(item: Budget) = viewModelScope.launch { db.budgetDao().delete(item) }
    fun addDebt(person: String, direction: String, amount: Long, note: String) = viewModelScope.launch { if (person.isNotBlank() && amount > 0) db.debtDao().insert(Debt(person = person, direction = direction, amount = amount, note = note)) }
    fun payDebt(item: Debt, payment: Long) = viewModelScope.launch { if (payment > 0 && item.paid + payment <= item.amount) db.debtDao().update(item.copy(paid = item.paid + payment)) }
    fun deleteDebt(item: Debt) = viewModelScope.launch { db.debtDao().delete(item) }
    fun addAccount(name: String, kind: String, opening: Long) = viewModelScope.launch { if (name.isNotBlank()) db.accountDao().insert(WalletAccount(name = name, kind = kind, openingBalance = opening)) }
    fun deleteAccount(item: WalletAccount) = viewModelScope.launch { db.accountDao().delete(item) }
    fun addGoal(name: String, target: Long) = viewModelScope.launch { if (name.isNotBlank() && target > 0) db.goalDao().insert(SavingsGoal(name = name, target = target)) }
    fun contribute(item: SavingsGoal, amount: Long) = viewModelScope.launch { if (amount > 0) db.goalDao().update(item.copy(saved = (item.saved + amount).coerceAtMost(item.target))) }
    fun deleteGoal(item: SavingsGoal) = viewModelScope.launch { db.goalDao().delete(item) }
}

@Suppress("UNCHECKED_CAST")
class WalletViewModelFactory(private val db: AppDatabase) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T = WalletViewModel(db) as T
}

@Composable
fun MahfazatiApp(db: AppDatabase) {
    val vm: WalletViewModel = viewModel(factory = WalletViewModelFactory(db))
    val transactions by vm.transactions.collectAsState()
    val balance by vm.balance.collectAsState()
    val budgets by vm.budgets.collectAsState()
    val debts by vm.debts.collectAsState()
    val accounts by vm.accounts.collectAsState()
    val goals by vm.goals.collectAsState()
    val totalBalance = balance + accounts.sumOf { it.openingBalance }
    var selected by remember { mutableIntStateOf(0) }
    var showBalance by remember { mutableStateOf(true) }
    var dialog by remember { mutableStateOf("") }
    var fixedType by remember { mutableStateOf("مصروف") }
    var search by remember { mutableStateOf("") }

    Scaffold(
        containerColor = Pale,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                val labels = listOf("الرئيسية", "العمليات", "الميزانية", "التقارير", "المزيد")
                val icons = listOf(Icons.Default.Home, Icons.Default.ReceiptLong, Icons.Default.Wallet, Icons.Default.Analytics, Icons.Default.MoreHoriz)
                labels.forEachIndexed { i, label -> NavigationBarItem(selected = selected == i, onClick = { selected = i }, icon = { Icon(icons[i], null) }, label = { Text(label) }) }
            }
        }
    ) { padding ->
        when (selected) {
            0 -> Dashboard(Modifier.padding(padding), totalBalance, transactions, showBalance, { showBalance = !showBalance }, onIncome = { fixedType = "دخل"; dialog = "transaction" }, onExpense = { fixedType = "مصروف"; dialog = "transaction" }, onBudget = { dialog = "budget" })
            1 -> TransactionsScreen(Modifier.padding(padding), transactions, search, { search = it }, vm::deleteTransaction)
            2 -> BudgetsScreen(Modifier.padding(padding), budgets, transactions, vm::deleteBudget, { dialog = "budget" })
            3 -> ReportsScreen(Modifier.padding(padding), transactions)
            else -> MoreScreen(Modifier.padding(padding), debts, accounts, goals,
                onDebt = { dialog = "debt" }, onAccount = { dialog = "account" }, onGoal = { dialog = "goal" },
                onPayDebt = { item -> dialog = "pay:${item.id}" }, onContribute = { item -> dialog = "goalpay:${item.id}" },
                onDeleteDebt = vm::deleteDebt, onDeleteAccount = vm::deleteAccount, onDeleteGoal = vm::deleteGoal)
        }
    }
    when {
        dialog == "transaction" -> TransactionDialog(fixedType, accounts, { dialog = "" }) { amount, type, category, note, account -> vm.addTransaction(amount, type, category, note, account); dialog = "" }
        dialog == "budget" -> BudgetDialog({ dialog = "" }) { n, c, a, p -> vm.addBudget(n, c, a, p); dialog = "" }
        dialog == "debt" -> DebtDialog({ dialog = "" }) { p, d, a, n -> vm.addDebt(p, d, a, n); dialog = "" }
        dialog == "account" -> AccountDialog({ dialog = "" }) { n, k, b -> vm.addAccount(n, k, b); dialog = "" }
        dialog == "goal" -> GoalDialog({ dialog = "" }) { n, t -> vm.addGoal(n, t); dialog = "" }
        dialog.startsWith("pay:") -> {
            val id = dialog.substringAfter(":").toLongOrNull()
            val item = debts.firstOrNull { it.id == id }
            if (item != null) AmountDialog("تسجيل سداد", { dialog = "" }) { vm.payDebt(item, it); dialog = "" }
        }
        dialog.startsWith("goalpay:") -> {
            val id = dialog.substringAfter(":").toLongOrNull()
            val item = goals.firstOrNull { it.id == id }
            if (item != null) AmountDialog("إضافة مبلغ للهدف", { dialog = "" }) { vm.contribute(item, it); dialog = "" }
        }
    }
}

@Composable
fun Dashboard(modifier: Modifier, balance: Long, transactions: List<Transaction>, showBalance: Boolean, toggle: () -> Unit, onIncome: () -> Unit, onExpense: () -> Unit, onBudget: () -> Unit) {
    val now = System.currentTimeMillis()
    val monthStart = java.util.Calendar.getInstance().apply { set(java.util.Calendar.DAY_OF_MONTH, 1); set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0) }.timeInMillis
    val month = transactions.filter { it.dateMillis >= monthStart }
    val income = month.filter { it.type == "دخل" }.sumOf { it.amount }
    val expense = month.filter { it.type == "مصروف" }.sumOf { it.amount }
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        item { Text("مرحباً بك في محفظتي", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink); Text("نظّم أموالك وراقب مصروفاتك", color = Color.Gray) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF123D32)), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("إجمالي الرصيد", color = Color.White.copy(.85f)); IconButton(onClick = toggle) { Icon(if (showBalance) Icons.Default.Visibility else Icons.Default.VisibilityOff, null, tint = Color.White) } }
                    Text(if (showBalance) money(balance) else "•••••• د.ع", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text("الدينار العراقي", color = Color.White.copy(.8f))
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { SummaryCard("دخل هذا الشهر", income, IncomeGreen, Modifier.weight(1f)); SummaryCard("مصروفات هذا الشهر", expense, ExpenseRed, Modifier.weight(1f)) } }
        item {
            val expenseGroups = month.filter { it.type == "مصروف" }.groupBy { it.category }
                .mapValues { entry -> entry.value.sumOf { it.amount } }.toList().sortedByDescending { it.second }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("مصروفاتي حسب التصنيف", fontWeight = FontWeight.Bold, color = Ink, style = MaterialTheme.typography.titleMedium)
                if (expenseGroups.isEmpty()) Text("ستظهر هنا مصروفات الطعام والصحة والنقل وغيرها بعد تسجيلها.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                expenseGroups.forEach { (category, amount) ->
                    Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(category, color = Ink, fontWeight = FontWeight.Medium)
                        Text("− ${money(amount)} د.ع", color = ExpenseRed, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Text("إضافة سريعة", fontWeight = FontWeight.Bold, color = Ink, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(9.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAction("إضافة دخل", "+", IncomeGreen, Modifier.weight(1f), onIncome)
                QuickAction("إضافة مصروف", "−", ExpenseRed, Modifier.weight(1f), onExpense)
            }
        }
        item { OutlinedButton(onClick = onBudget, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Wallet, null); Spacer(Modifier.width(8.dp)); Text("إنشاء ميزانية") } }
        item { Text("آخر العمليات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Ink) }
        if (transactions.isEmpty()) item { EmptyState() } else items(transactions.take(6), key = { it.id }) { TransactionRow(it) }
    }
}

@Composable
fun QuickAction(title: String, symbol: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Box(Modifier.size(34.dp).background(color.copy(.12f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text(symbol, color = color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge) }
            Spacer(Modifier.width(8.dp)); Text(title, color = color, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun SummaryCard(title: String, amount: Long, color: Color, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(14.dp)) { Text(title, color = Color.Gray, style = MaterialTheme.typography.bodySmall); Spacer(Modifier.height(8.dp)); Text(money(amount), color = color, fontWeight = FontWeight.Bold); Text("د.ع", color = Color.Gray, style = MaterialTheme.typography.labelSmall) }
    }
}

@Composable
fun TransactionsScreen(modifier: Modifier, transactions: List<Transaction>, search: String, onSearch: (String) -> Unit, onDelete: (Transaction) -> Unit) {
    val filtered = transactions.filter { it.category.contains(search, true) || it.note.contains(search, true) || it.amount.toString().contains(search) || it.type.contains(search) }
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("سجل العمليات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(search, onSearch, modifier = Modifier.fillMaxWidth(), label = { Text("ابحث بالمبلغ أو التصنيف أو الملاحظة") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Spacer(Modifier.height(12.dp))
        if (filtered.isEmpty()) EmptyState() else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(filtered, key = { it.id }) { item -> Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f)) { TransactionRow(item) }; TextButton(onClick = { onDelete(item) }) { Text("حذف", color = ExpenseRed) } } } }
    }
}

@Composable
fun TransactionRow(item: Transaction) {
    val isIncome = item.type == "دخل"
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).background(if (isIncome) Color(0xFFE5F5ED) else Color(0xFFFFEEEE), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Text(if (isIncome) "+" else "−", color = if (isIncome) IncomeGreen else ExpenseRed, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) { Text(item.category, fontWeight = FontWeight.SemiBold, color = Ink); Text("${item.account} • ${dateText(item.dateMillis)}", color = Color.Gray, style = MaterialTheme.typography.labelSmall); if (item.note.isNotBlank()) Text(item.note, color = Color.Gray, style = MaterialTheme.typography.bodySmall) }
            Text("${if (isIncome) "+" else "−"}${money(item.amount)}", color = if (isIncome) IncomeGreen else ExpenseRed, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun BudgetsScreen(modifier: Modifier, budgets: List<Budget>, transactions: List<Transaction>, onDelete: (Budget) -> Unit, onAdd: () -> Unit) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("الميزانيات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Button(onClick = onAdd) { Icon(Icons.Default.Add, null); Text("إضافة") } }
        Spacer(Modifier.height(12.dp))
        if (budgets.isEmpty()) EmptyPanel("لا توجد ميزانيات", "أنشئ ميزانية لتتابع إنفاقك حسب التصنيف أو الفترة.") else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(budgets, key = { it.id }) { budget ->
                val periodStart = periodStartMillis(budget.period)
                val spent = transactions.filter { it.type == "مصروف" && it.category == budget.category && it.dateMillis >= periodStart }.sumOf { it.amount }
                val progress = (spent.toFloat() / budget.amount.coerceAtLeast(1)).coerceIn(0f, 1f)
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(budget.name, fontWeight = FontWeight.Bold); Text(budget.period, color = Color.Gray) }
                        Text("${budget.category} • ${money(spent)} من ${money(budget.amount)} د.ع", style = MaterialTheme.typography.bodySmall)
                        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = ExpenseRed)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("المتبقي: ${money((budget.amount - spent).coerceAtLeast(0))} د.ع", color = if (spent > budget.amount) ExpenseRed else Emerald, style = MaterialTheme.typography.bodySmall); TextButton(onClick = { onDelete(budget) }) { Text("حذف") } }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportsScreen(modifier: Modifier, transactions: List<Transaction>) {
    val income = transactions.filter { it.type == "دخل" }.sumOf { it.amount }
    val expense = transactions.filter { it.type == "مصروف" }.sumOf { it.amount }
    val grouped = transactions.filter { it.type == "مصروف" }.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }.toList().sortedByDescending { it.second }
    LazyColumn(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("التقارير والإحصائيات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { SummaryCard("إجمالي الدخل", income, IncomeGreen, Modifier.weight(1f)); SummaryCard("إجمالي المصروفات", expense, ExpenseRed, Modifier.weight(1f)) } }
        item { SummaryCard("صافي التدفق المالي", income - expense, if (income >= expense) IncomeGreen else ExpenseRed, Modifier.fillMaxWidth()) }
        item { Text("أين اختفت أموالي؟", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        if (grouped.isEmpty()) item { EmptyPanel("لا توجد مصروفات للتحليل", "عند تسجيل المصروفات ستظهر هنا أكثر التصنيفات استهلاكاً.") }
        items(grouped) { (category, amount) ->
            val share = if (expense > 0) amount.toFloat() / expense else 0f
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(category, fontWeight = FontWeight.SemiBold); Text("${(share * 100).toInt()}%", color = ExpenseRed) }; Text("${money(amount)} د.ع", color = ExpenseRed); LinearProgressIndicator(progress = { share }, modifier = Modifier.fillMaxWidth(), color = ExpenseRed) }
            }
        }
        item { Text("التحليل مبني على العمليات المسجلة فقط. لا تُعرض توقعات أو أرقام غير موجودة في بياناتك.", color = Color.Gray, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun MoreScreen(modifier: Modifier, debts: List<Debt>, accounts: List<WalletAccount>, goals: List<SavingsGoal>, onDebt: () -> Unit, onAccount: () -> Unit, onGoal: () -> Unit, onPayDebt: (Debt) -> Unit, onContribute: (SavingsGoal) -> Unit, onDeleteDebt: (Debt) -> Unit, onDeleteAccount: (WalletAccount) -> Unit, onDeleteGoal: (SavingsGoal) -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { Text("المزيد", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item {
            val debtTotal = debts.sumOf { (it.amount - it.paid).coerceAtLeast(0) }
            val savingsTotal = goals.sumOf { it.saved }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryCard("الديون المتبقية", debtTotal, IncomeGreen, Modifier.weight(1f))
                SummaryCard("إجمالي المدخرات", savingsTotal, IncomeGreen, Modifier.weight(1f))
            }
        }
        item { SectionHeader("الديون", "تتبع الأموال التي لك أو عليك", onDebt) }
        if (debts.isEmpty()) item { EmptyPanel("لا توجد ديون مسجلة", "أضف ديناً مستحقاً لك أو مبلغاً عليك.") }
        items(debts, key = { "d${it.id}" }) { debt ->
            val remaining = (debt.amount - debt.paid).coerceAtLeast(0)
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(14.dp)) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(debt.person, fontWeight = FontWeight.Bold); Text(if (debt.direction == "لي") "دين لي" else "دين عليّ", color = IncomeGreen) }; Text("الأصل: ${money(debt.amount)} • المسدد: ${money(debt.paid)} • المتبقي: ${money(remaining)} د.ع", color = IncomeGreen, style = MaterialTheme.typography.bodySmall); Row { TextButton(onClick = { onPayDebt(debt) }, enabled = remaining > 0) { Text("تسجيل سداد") }; TextButton(onClick = { onDeleteDebt(debt) }) { Text("حذف", color = ExpenseRed) } } } }
        }
        item { Divider(); SectionHeader("الحسابات والمحافظ", "نقداً أو مصرف أو محفظة إلكترونية", onAccount) }
        if (accounts.isEmpty()) item { EmptyPanel("لا توجد حسابات إضافية", "أضف حساباتك لمساعدتك على تنظيم أموالك.") }
        items(accounts, key = { "a${it.id}" }) { account -> Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) { Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) { Column { Text(account.name, fontWeight = FontWeight.Bold); Text("${account.kind} • رصيد افتتاحي ${money(account.openingBalance)} د.ع", color = Color.Gray, style = MaterialTheme.typography.bodySmall) }; TextButton(onClick = { onDeleteAccount(account) }) { Text("حذف") } } } }
        item { Divider(); SectionHeader("أهداف الادخار", "تابع تقدمك نحو أهدافك", onGoal) }
        if (goals.isEmpty()) item { EmptyPanel("لم تضف أهدافاً بعد", "حدد هدفاً وابدأ بمتابعة ما ادخرته.") }
        items(goals, key = { "g${it.id}" }) { goal -> val p = (goal.saved.toFloat() / goal.target.coerceAtLeast(1)).coerceIn(0f, 1f); Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(goal.name, fontWeight = FontWeight.Bold); Text("${(p * 100).toInt()}%", color = IncomeGreen) }; LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth()); Text("${money(goal.saved)} من ${money(goal.target)} د.ع", color = IncomeGreen, style = MaterialTheme.typography.bodySmall); Row { TextButton(onClick = { onContribute(goal) }, enabled = goal.saved < goal.target) { Text("إضافة ادخار") }; TextButton(onClick = { onDeleteGoal(goal) }) { Text("حذف") } } } } }
        item { Divider(); Text("محفظتي | Mahfazati", fontWeight = FontWeight.Bold); Text("Developed by M.Z DIGITAL\n© 2026 M.Z DIGITAL. All Rights Reserved.", color = Color.Gray, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun SectionHeader(title: String, subtitle: String, onAdd: () -> Unit) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Color.Gray) }; FilledTonalButton(onClick = onAdd) { Icon(Icons.Default.Add, null); Text("إضافة") } } }

@Composable
fun TransactionDialog(type: String, accounts: List<WalletAccount>, onDismiss: () -> Unit, onSave: (Long, String, String, String, String) -> Unit) {
    var amount by remember { mutableStateOf("") }; var category by remember { mutableStateOf(if (type == "دخل") "الراتب" else "الطعام والشراب") }; var note by remember { mutableStateOf("") }; var account by remember { mutableStateOf("نقداً") }; var error by remember { mutableStateOf(false) }
    val categories = if (type == "دخل") listOf("الراتب", "العمل الإضافي", "التجارة", "الهدايا", "المشاريع", "أخرى") else listOf("الطعام والشراب", "الصحة", "النقل والمواصلات", "السكن والمنزل", "التسوق", "الفواتير", "الإنترنت والاتصالات", "التعليم", "الترفيه", "العناية الشخصية", "الصيانة", "أخرى")
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (type == "دخل") "إضافة دخل" else "إضافة مصروف") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(if (type == "دخل") "سيُسجل المبلغ كدخل" else "سيُسجل المبلغ كمصروف", color = if (type == "دخل") IncomeGreen else ExpenseRed, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(amount, { amount = it.filter(Char::isDigit); error = false }, label = { Text("المبلغ (ألف دينار عراقي)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            Text("كل 1 = 1,000 دينار عراقي", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
            Text("التصنيف", fontWeight = FontWeight.SemiBold)
            Column(Modifier.heightIn(max = 145.dp)) { categories.chunked(2).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { row.forEach { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) }) } } } }
            Text("الحساب", fontWeight = FontWeight.SemiBold)
            var accountExpanded by remember { mutableStateOf(false) }
            Box { OutlinedButton(onClick = { accountExpanded = true }) { Text(account) }; DropdownMenu(expanded = accountExpanded, onDismissRequest = { accountExpanded = false }) { (listOf("نقداً") + accounts.map { it.name }).distinct().forEach { a -> DropdownMenuItem(text = { Text(a) }, onClick = { account = a; accountExpanded = false }) } } }
            OutlinedTextField(note, { note = it }, label = { Text("ملاحظة اختيارية") }, singleLine = true)
            if (error) Text("أدخل مبلغاً صحيحاً أكبر من صفر", color = MaterialTheme.colorScheme.error)
        }
    }, confirmButton = { TextButton(onClick = { val v = parseThousandsToDinars(amount); if (v == null || v <= 0) error = true else onSave(v, type, category, note.trim(), account) }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun BudgetDialog(onDismiss: () -> Unit, onSave: (String, String, Long, String) -> Unit) {
    var name by remember { mutableStateOf("") }; var category by remember { mutableStateOf("الطعام والشراب") }; var amount by remember { mutableStateOf("") }; var period by remember { mutableStateOf("شهري") }; var error by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إنشاء ميزانية") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(name, { name = it }, label = { Text("اسم الميزانية") }, singleLine = true); OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("المبلغ (ألف دينار عراقي)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)); Text("التصنيف"); CategoryPicker(category, { category = it }, listOf("الطعام والشراب", "الصحة", "النقل والمواصلات", "السكن والمنزل", "التسوق", "الفواتير", "الإنترنت والاتصالات", "التعليم", "الترفيه", "العناية الشخصية", "الصيانة", "أخرى")); Text("الفترة"); Row { listOf("يومي", "أسبوعي", "شهري").forEach { FilterChip(selected = period == it, onClick = { period = it }, label = { Text(it) }) } }; if (error) Text("أكمل البيانات بمبلغ صحيح", color = ExpenseRed) } }, confirmButton = { TextButton(onClick = { val a = parseThousandsToDinars(amount); if (name.isBlank() || a == null || a <= 0) error = true else onSave(name, category, a, period) }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun CategoryPicker(selected: String, onSelect: (String) -> Unit, values: List<String>) { var expanded by remember { mutableStateOf(false) }; Box { OutlinedButton(onClick = { expanded = true }) { Text(selected) }; DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { values.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { onSelect(it); expanded = false }) } } } }

@Composable
fun DebtDialog(onDismiss: () -> Unit, onSave: (String, String, Long, String) -> Unit) {
    var person by remember { mutableStateOf("") }; var direction by remember { mutableStateOf("لي") }; var amount by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }; var error by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة دين") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(person, { person = it }, label = { Text("اسم الشخص") }); Row { FilterChip(direction == "لي", { direction = "لي" }, label = { Text("دين لي") }); Spacer(Modifier.width(8.dp)); FilterChip(direction == "عليّ", { direction = "عليّ" }, label = { Text("دين عليّ") }) }; OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("المبلغ (ألف دينار عراقي)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)); OutlinedTextField(note, { note = it }, label = { Text("ملاحظات") }); if (error) Text("أدخل الاسم والمبلغ", color = ExpenseRed) } }, confirmButton = { TextButton(onClick = { val a = parseThousandsToDinars(amount); if (person.isBlank() || a == null || a <= 0) error = true else onSave(person.trim(), direction, a, note.trim()) }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun AccountDialog(onDismiss: () -> Unit, onSave: (String, String, Long) -> Unit) {
    var name by remember { mutableStateOf("") }; var kind by remember { mutableStateOf("نقداً") }; var opening by remember { mutableStateOf("0") }; var error by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة حساب") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(name, { name = it }, label = { Text("اسم الحساب") }); CategoryPicker(kind, { kind = it }, listOf("نقداً", "حساب مصرفي", "محفظة إلكترونية", "آخر")); OutlinedTextField(opening, { opening = it.filter(Char::isDigit) }, label = { Text("الرصيد الافتتاحي (ألف دينار عراقي)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)); if (error) Text("أدخل اسم الحساب", color = ExpenseRed) } }, confirmButton = { TextButton(onClick = { val b = parseThousandsToDinars(opening) ?: -1L; if (name.isBlank() || b < 0) error = true else onSave(name.trim(), kind, b) }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun GoalDialog(onDismiss: () -> Unit, onSave: (String, Long) -> Unit) {
    var name by remember { mutableStateOf("") }; var target by remember { mutableStateOf("") }; var error by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("هدف ادخاري جديد") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(name, { name = it }, label = { Text("اسم الهدف") }); OutlinedTextField(target, { target = it.filter(Char::isDigit) }, label = { Text("المبلغ المستهدف (ألف دينار عراقي)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)); if (error) Text("أدخل اسم الهدف والمبلغ", color = ExpenseRed) } }, confirmButton = { TextButton(onClick = { val t = parseThousandsToDinars(target); if (name.isBlank() || t == null || t <= 0) error = true else onSave(name.trim(), t) }) { Text("إنشاء") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun AmountDialog(title: String, onDismiss: () -> Unit, onSave: (Long) -> Unit) {
    var amount by remember { mutableStateOf("") }; var error by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { Column { OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("المبلغ (ألف دينار عراقي)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)); if (error) Text("أدخل مبلغاً صحيحاً", color = ExpenseRed) } }, confirmButton = { TextButton(onClick = { val v = parseThousandsToDinars(amount); if (v == null || v <= 0) error = true else onSave(v) }) { Text("تأكيد") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun EmptyState() = EmptyPanel("لا توجد عمليات حتى الآن", "ابدأ بإضافة دخل أو مصروف لتظهر بياناتك هنا.")

@Composable
fun EmptyPanel(title: String, description: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Wallet, null, tint = Emerald, modifier = Modifier.size(34.dp)); Spacer(Modifier.height(8.dp)); Text(title, fontWeight = FontWeight.SemiBold); Text(description, color = Color.Gray, style = MaterialTheme.typography.bodySmall) } }
}

fun periodStartMillis(period: String): Long {
    val calendar = java.util.Calendar.getInstance()
    when (period) {
        "يومي" -> { calendar.set(java.util.Calendar.HOUR_OF_DAY, 0); calendar.set(java.util.Calendar.MINUTE, 0); calendar.set(java.util.Calendar.SECOND, 0); calendar.set(java.util.Calendar.MILLISECOND, 0) }
        "أسبوعي" -> { calendar.set(java.util.Calendar.DAY_OF_WEEK, calendar.firstDayOfWeek); calendar.set(java.util.Calendar.HOUR_OF_DAY, 0); calendar.set(java.util.Calendar.MINUTE, 0); calendar.set(java.util.Calendar.SECOND, 0); calendar.set(java.util.Calendar.MILLISECOND, 0) }
        else -> { calendar.set(java.util.Calendar.DAY_OF_MONTH, 1); calendar.set(java.util.Calendar.HOUR_OF_DAY, 0); calendar.set(java.util.Calendar.MINUTE, 0); calendar.set(java.util.Calendar.SECOND, 0); calendar.set(java.util.Calendar.MILLISECOND, 0) }
    }
    return calendar.timeInMillis
}

/** Converts user-entered thousands of Iraqi dinars to stored whole dinars.
 * Existing database values remain unchanged and continue to be stored in IQD.
 */
fun parseThousandsToDinars(input: String): Long? {
    val thousands = input.trim().toLongOrNull() ?: return null
    if (thousands < 0 || thousands > Long.MAX_VALUE / 1_000L) return null
    return thousands * 1_000L
}

fun money(value: Long): String = NumberFormat.getIntegerInstance(Locale("ar", "IQ")).format(value)
fun dateText(value: Long): String = SimpleDateFormat("yyyy/MM/dd", Locale("ar", "IQ")).format(Date(value))
