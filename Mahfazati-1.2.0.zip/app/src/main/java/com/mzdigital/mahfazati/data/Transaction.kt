package com.mzdigital.mahfazati.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Long,
    val type: String,
    val category: String,
    val account: String = "نقداً",
    val note: String = "",
    val dateMillis: Long = System.currentTimeMillis()
)
