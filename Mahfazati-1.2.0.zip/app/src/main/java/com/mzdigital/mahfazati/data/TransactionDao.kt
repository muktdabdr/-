package com.mzdigital.mahfazati.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY dateMillis DESC")
    fun observeAll(): Flow<List<Transaction>>

    @Insert
    suspend fun insert(item: Transaction)

    @Delete
    suspend fun delete(item: Transaction)

    @Query("SELECT COALESCE(SUM(CASE WHEN type = 'دخل' THEN amount ELSE -amount END), 0) FROM transactions")
    fun observeBalance(): Flow<Long>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE type = 'دخل' AND dateMillis >= :start")
    fun observeIncomeSince(start: Long): Flow<Long>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE type = 'مصروف' AND dateMillis >= :start")
    fun observeExpenseSince(start: Long): Flow<Long>
}
