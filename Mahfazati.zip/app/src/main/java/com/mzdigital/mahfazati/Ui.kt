package com.mzdigital.mahfazati

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

val df = SimpleDateFormat("yyyy/MM/dd", Locale.US)

@Composable
fun App(vm: VM) {
    val n by vm.name.collectAsState()
    val s = n
    when {
        s == null -> Box(Modifier.fillMaxSize())
        s == "" -> Onboarding { vm.setup(it) }
        else -> Main(vm, s)
    }
}

@Composable
fun Onboarding(onDone: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("محفظتي", fontSize = 40.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Mahfazati", color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        Text("اعرف أين تذهب أموالك، وكم تبقّى منها.")
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(name, { name = it }, label = { Text("ما اسمك؟") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button({ if (name.isNotBlank()) onDone(name.trim()) }, Modifier.fillMaxWidth()) { Text("ابدأ") }
    }
}

@Composable
fun Main(vm: VM, name: String) {
    val nav = rememberNavController()
    val tabs = listOf(
        Triple("home", "الرئيسية", Icons.Default.Home), Triple("income", "الدخل", Icons.Default.Add), Triple("tx", "العمليات", Icons.Default.List),
        Triple("budget", "الميزانية", Icons.Default.DateRange), Triple("insights", "أين أموالي", Icons.Default.Search),
        Triple("more", "المزيد", Icons.Default.Menu)
    )
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    Scaffold(bottomBar = {
        if (route in tabs.map { it.first }) NavigationBar {
            tabs.forEach { (r, l, i) ->
                NavigationBarItem(selected = route == r, onClick = { nav.navigate(r) { popUpTo("home"); launchSingleTop = true } },
                    icon = { Icon(i, null) }, label = { Text(l, fontSize = 10.sp) })
            }
        }
    }) { pad ->
        NavHost(nav, "home", Modifier.padding(pad)) {
            composable("home") { Home(vm, name, nav) }
            composable("tx") { TxScreen(vm, nav) }
            composable("income") { IncomeScreen(vm, nav) }
            composable("add") { AddTx(vm, nav, "EXPENSE") }
            composable("addIncome") { AddTx(vm, nav, "INCOME") }
            composable("addExpense") { AddTx(vm, nav, "EXPENSE") }
            composable("budget") { BudgetScreen(vm) }
            composable("insights") { Insights(vm) }
            composable("more") { More(vm, nav) }
            composable("debts") { DebtsScreen(vm) }
            composable("accounts") { AccountsScreen(vm) }
            composable("goals") { GoalsScreen(vm) }
            composable("about") { About() }
        }
    }
}

@Composable fun Empty(t: String) { Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { Text(t) } }

@Composable fun Stat(t: String, v: String, c: Color, m: Modifier) {
    Card(m) { Column(Modifier.padding(14.dp)) { Text(t, fontSize = 12.sp); Text(v, color = c, fontWeight = FontWeight.Bold) } }
}

@Composable fun Fab(onClick: () -> Unit, m: Modifier) {
    FloatingActionButton(onClick, m.padding(16.dp)) { Icon(Icons.Default.Add, "إضافة") }
}

@Composable fun <T> Chips(items: List<Pair<T, String>>, sel: T?, onSel: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { (k, l) -> FilterChip(selected = sel == k, onClick = { onSel(k) }, label = { Text(l) }) }
    }
}

@Composable
fun InputDialog(title: String, labels: List<String>, numeric: List<Boolean> = labels.map { false }, onDismiss: () -> Unit, onOk: (List<String>) -> Unit) {
    val vals = remember { mutableStateListOf(*Array(labels.size) { "" }) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                labels.forEachIndexed { i, l ->
                    OutlinedTextField(vals[i], { vals[i] = if (numeric[i]) it.filter(Char::isDigit) else it }, label = { Text(l) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = if (numeric[i]) KeyboardType.Number else KeyboardType.Text))
                }
            }
        },
        confirmButton = { TextButton({ onOk(vals.toList()) }) { Text("حفظ") } },
        dismissButton = { TextButton(onDismiss) { Text("إلغاء") } })
}

@Composable
fun TxRow(t: Tx, vm: VM) {
    val c = when (t.type) { "INCOME" -> GreenC; "EXPENSE" -> RedC; else -> MaterialTheme.colorScheme.onSurface }
    val sign = when (t.type) { "INCOME" -> "+"; "EXPENSE" -> "-"; else -> "" }
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(if (t.type == "TRANSFER") "تحويل" else t.category, fontWeight = FontWeight.Bold)
                Text(df.format(Date(t.date)) + if (t.note.isNotBlank()) " • " + t.note else "", fontSize = 12.sp)
            }
            Text(sign + vm.money(t.amount), color = c, fontWeight = FontWeight.Bold)
            IconButton({ vm.delTx(t) }) { Icon(Icons.Default.Delete, "حذف") }
        }
    }
}

@Composable
fun Home(vm: VM, name: String, nav: NavHostController) {
    val txs by vm.txs.collectAsState()
    val accs by vm.accounts.collectAsState()
    val buds by vm.budgets.collectAsState()
    val goals by vm.goals.collectAsState()
    val ms = monthStart()
    val total = accs.sumOf { bal(it, txs) }
    val inc = txs.filter { it.type == "INCOME" && it.date >= ms }.sumOf { it.amount }
    val exp = txs.spent(ms)
    val cap = buds.firstOrNull { it.category == "ALL" }?.cap
    Box(Modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 88.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("أهلاً $name 👋", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
                    TextButton({ vm.hidden = !vm.hidden }) { Text(if (vm.hidden) "إظهار الأرصدة" else "إخفاء الأرصدة") }
                }
            }
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                    Column(Modifier.padding(20.dp)) {
                        Text("إجمالي الرصيد", color = MaterialTheme.colorScheme.onPrimary)
                        Text(vm.money(total), style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Stat("الدخل هذا الشهر", vm.money(inc), GreenC, Modifier.weight(1f))
                    Stat("المصروفات هذا الشهر", vm.money(exp), RedC, Modifier.weight(1f))
                }
            }
            item {
                val saved = goals.sumOf { it.saved }
                Stat("إجمالي المدخرات", vm.money(saved), GreenC, Modifier.fillMaxWidth())
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { nav.navigate("addIncome") }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = GreenC)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("إضافة دخل") }
                    Button(onClick = { nav.navigate("addExpense") }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = RedC)) { Icon(Icons.Default.Remove, null); Spacer(Modifier.width(5.dp)); Text("إضافة مصروف") }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        if (cap == null) Text("لم تحدد ميزانية شهرية بعد (من تبويب الميزانية).")
                        else {
                            Text("المتبقي من الميزانية: " + vm.money(cap - exp), fontWeight = FontWeight.Bold, color = if (exp > cap) RedC else MaterialTheme.colorScheme.onSurface)
                            LinearProgressIndicator(progress = { (exp.toFloat() / cap).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                        }
                    }
                }
            }
            item { Text("آخر العمليات", style = MaterialTheme.typography.titleMedium) }
            if (txs.isEmpty()) item { Empty("لا توجد عمليات بعد. اضغط + لإضافة أول عملية.") }
            items(txs.take(5), key = { it.id }) { TxRow(it, vm) }
        }
        Fab({ nav.navigate("add") }, Modifier.align(Alignment.BottomStart))
    }
}

@Composable
fun IncomeScreen(vm: VM, nav: NavHostController) {
    val txs by vm.txs.collectAsState()
    val list = txs.filter { it.type == "INCOME" }
    val total = list.sumOf { it.amount }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("الدخل", style = MaterialTheme.typography.headlineSmall, color = GreenC)
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = GreenC.copy(alpha = 0.10f))) {
                Column(Modifier.padding(16.dp)) {
                    Text("إجمالي الدخل المسجل", color = GreenC)
                    Text(vm.money(total), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = GreenC)
                }
            }
            LazyColumn(contentPadding = PaddingValues(bottom = 88.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (list.isEmpty()) item { Empty("لا توجد إيرادات مسجلة. أضف أول دخل لك.") }
                items(list, key = { it.id }) { TxRow(it, vm) }
            }
        }
        Fab({ nav.navigate("addIncome") }, Modifier.align(Alignment.BottomStart))
    }
}

@Composable
fun TxScreen(vm: VM, nav: NavHostController) {
    val txs by vm.txs.collectAsState()
    var q by remember { mutableStateOf("") }
    var f by remember { mutableStateOf("ALL") }
    val list = txs.filter {
        (f == "ALL" || it.type == f) && (q.isBlank() || it.category.contains(q) || it.note.contains(q) ||
            it.amount.toString().contains(q) || df.format(Date(it.date)).contains(q))
    }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(q, { q = it }, label = { Text("بحث: مبلغ، تصنيف، ملاحظة، تاريخ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Chips(listOf("ALL" to "الكل", "INCOME" to "دخل", "EXPENSE" to "مصروف", "TRANSFER" to "تحويل"), f) { f = it }
            LazyColumn(contentPadding = PaddingValues(bottom = 88.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (list.isEmpty()) item { Empty("لا توجد عمليات") }
                items(list, key = { it.id }) { TxRow(it, vm) }
            }
        }
        Fab({ nav.navigate("add") }, Modifier.align(Alignment.BottomStart))
    }
}

@Composable
fun AddTx(vm: VM, nav: NavHostController, startType: String = "EXPENSE") {
    val accs by vm.accounts.collectAsState()
    var type by remember(startType) { mutableStateOf(startType) }
    var amount by remember { mutableStateOf("") }
    var cat by remember(startType) { mutableStateOf(if (startType == "INCOME") INC[0] else EXP[0]) }
    var acc by remember { mutableStateOf<Long?>(null) }
    var to by remember { mutableStateOf<Long?>(null) }
    var note by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val a = acc ?: accs.firstOrNull()?.id
    val accItems = accs.map { it.id to it.name }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("عملية جديدة", style = MaterialTheme.typography.headlineSmall)
        Chips(listOf("EXPENSE" to "مصروف", "INCOME" to "دخل", "TRANSFER" to "تحويل"), type) { type = it; cat = if (it == "INCOME") INC[0] else EXP[0] }
        OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("المبلغ (بالألف دينار)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        if (type != "TRANSFER") { Text("التصنيف"); Chips((if (type == "INCOME") INC else EXP).map { it to it }, cat) { cat = it } }
        Text(if (type == "TRANSFER") "من حساب" else "الحساب"); Chips(accItems, a) { acc = it }
        if (type == "TRANSFER") { Text("إلى حساب"); Chips(accItems, to) { to = it } }
        OutlinedTextField(note, { note = it }, label = { Text("ملاحظة (اختياري)") }, modifier = Modifier.fillMaxWidth())
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button({
            val v = amount.toIqdThousands()
            when {
                v <= 0L -> err = "أدخل مبلغاً صحيحاً"
                a == null -> err = "لا يوجد حساب"
                type == "TRANSFER" && (to == null || to == a) -> err = "اختر حسابين مختلفين"
                else -> {
                    vm.addTx(Tx(type = type, amount = v, category = if (type == "TRANSFER") "تحويل" else cat, accountId = a,
                        toAccountId = if (type == "TRANSFER") to else null, date = System.currentTimeMillis(), note = note.trim()))
                    nav.popBackStack()
                }
            }
        }, Modifier.fillMaxWidth()) { Text("حفظ") }
    }
}

@Composable
fun BudgetScreen(vm: VM) {
    val txs by vm.txs.collectAsState()
    val buds by vm.budgets.collectAsState()
    var edit by remember { mutableStateOf<String?>(null) }
    val rows = listOf("ALL" to "الميزانية الشهرية الإجمالية") + EXP.map { it to it }
    val ms = monthStart()
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("الميزانيات (شهرياً)", style = MaterialTheme.typography.headlineSmall) }
        items(rows) { (k, l) ->
            val cap = buds.firstOrNull { it.category == k }?.cap ?: 0L
            val sp = txs.spent(ms, cat = if (k == "ALL") null else k)
            Card(Modifier.fillMaxWidth().clickable { edit = k }) {
                Column(Modifier.padding(14.dp)) {
                    Text(l, fontWeight = FontWeight.Bold)
                    if (cap == 0L) Text("اضغط لتحديد ميزانية", fontSize = 12.sp)
                    else {
                        val pct = (sp * 100 / cap).toInt()
                        val col = if (pct >= 90) RedC else if (pct >= 70) WarnC else MaterialTheme.colorScheme.primary
                        LinearProgressIndicator(progress = { (sp.toFloat() / cap).coerceIn(0f, 1f) }, color = col, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                        Text("المحدد ${cap.fmt()} • المستهلك ${sp.fmt()} ($pct%)", fontSize = 12.sp)
                        Text(if (sp > cap) "تجاوزت الميزانية بمقدار ${(sp - cap).fmt()}" else "المتبقي ${(cap - sp).fmt()}", color = col, fontSize = 12.sp)
                        if (pct in 70..99) Text("تنبيه: استهلكت $pct% من الميزانية", color = WarnC, fontSize = 12.sp)
                    }
                }
            }
        }
    }
    edit?.let { k ->
        InputDialog("تحديد الميزانية الشهرية", listOf("المبلغ بالألف دينار (0 للإزالة)"), listOf(true), { edit = null }) { vm.setBudget(k, it[0].toIqdThousands()); edit = null }
    }
}

@Composable
fun Insights(vm: VM) {
    val txs by vm.txs.collectAsState()
    val ms = monthStart(); val pm = monthStart(-1)
    val cur = txs.spent(ms); val prev = txs.spent(pm, ms)
    val byCat = EXP.map { it to txs.spent(ms, cat = it) }.filter { it.second > 0 }.sortedByDescending { it.second }
    val prevBy = EXP.associateWith { txs.spent(pm, ms, it) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("أين اختفت أموالي؟", style = MaterialTheme.typography.headlineSmall) }
        if (cur == 0L) item { Empty("لا توجد مصروفات هذا الشهر بعد. سجّل مصروفاتك لتظهر التحليلات.") }
        else {
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("أنفقت هذا الشهر"); Text(vm.money(cur), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = RedC) } } }
            item { Text("أكثر الأبواب استهلاكاً", style = MaterialTheme.typography.titleMedium) }
            items(byCat.take(3)) { (c, v) ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text("$c: ${vm.money(v)}", fontWeight = FontWeight.Bold)
                        LinearProgressIndicator(progress = { v.toFloat() / cur }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                    }
                }
            }
            val msgs = mutableListOf<String>()
            val (tc, tv) = byCat[0]
            msgs += "«$tc» يستهلك ${tv * 100 / cur}% من مصروفاتك هذا الشهر."
            byCat.take(3).forEach { (c, v) ->
                val p = prevBy[c] ?: 0L
                if (p > 0) {
                    val ch = (v - p) * 100 / p
                    if (ch > 0) msgs += "ارتفع إنفاق «$c» بنسبة $ch% مقارنة بالشهر الماضي."
                    else if (ch < 0) msgs += "انخفض إنفاق «$c» بنسبة ${-ch}% مقارنة بالشهر الماضي."
                }
            }
            if (prev > 0) msgs += "إجمالي إنفاقك ${if (cur >= prev) "أعلى" else "أقل"} من الشهر الماضي بمقدار ${abs(cur - prev).fmt()}."
            msgs += "لو خفّضت «$tc» بنسبة 10% لوفّرت ${(tv / 10).fmt()}."
            item { Text("تحليل", style = MaterialTheme.typography.titleMedium) }
            items(msgs) { Card(Modifier.fillMaxWidth()) { Text(it, Modifier.padding(14.dp)) } }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text("مقارنة بالشهر الماضي", fontWeight = FontWeight.Bold)
                        Text("الشهر الحالي: ${vm.money(cur)}"); Text("الشهر الماضي: ${vm.money(prev)}")
                    }
                }
            }
        }
    }
}

@Composable
fun More(vm: VM, nav: NavHostController) {
    var ren by remember { mutableStateOf(false) }
    var wipe by remember { mutableStateOf(false) }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(8.dp)) {
        listOf("debts" to "الديون", "accounts" to "الحسابات والمحافظ", "goals" to "المدخرات والأهداف", "about" to "حول التطبيق").forEach { (r, l) ->
            ListItem(headlineContent = { Text(l) }, modifier = Modifier.clickable { nav.navigate(r) })
        }
        ListItem(headlineContent = { Text("تغيير الاسم") }, modifier = Modifier.clickable { ren = true })
        ListItem(headlineContent = { Text("حذف جميع البيانات", color = RedC) }, modifier = Modifier.clickable { wipe = true })
    }
    if (ren) InputDialog("تغيير الاسم", listOf("الاسم"), onDismiss = { ren = false }) { if (it[0].isNotBlank()) vm.rename(it[0].trim()); ren = false }
    if (wipe) AlertDialog(onDismissRequest = { wipe = false }, title = { Text("حذف جميع البيانات؟") },
        text = { Text("سيتم حذف كل العمليات والحسابات والديون والأهداف نهائياً.") },
        confirmButton = { TextButton({ vm.wipe(); wipe = false }) { Text("حذف", color = RedC) } },
        dismissButton = { TextButton({ wipe = false }) { Text("إلغاء") } })
}

@Composable
fun DebtsScreen(vm: VM) {
    val debts by vm.debts.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var add by remember { mutableStateOf(false) }
    var pay by remember { mutableStateOf<Debt?>(null) }
    val list = debts.filter { it.owedToMe == (tab == 0) }
    Box(Modifier.fillMaxSize()) {
        Column {
            TabRow(selectedTabIndex = tab) {
                Tab(tab == 0, { tab = 0 }) { Text("ديون لي", Modifier.padding(12.dp)) }
                Tab(tab == 1, { tab = 1 }) { Text("ديون عليّ", Modifier.padding(12.dp)) }
            }
            LazyColumn(contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 88.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (list.isEmpty()) item { Empty("لا توجد ديون مسجلة") }
                items(list, key = { it.id }) { d ->
                    val rem = d.amount - d.paid
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = GreenC.copy(alpha = 0.06f))) {
                        Column(Modifier.padding(12.dp)) {
                            Text(d.person, fontWeight = FontWeight.Bold, color = GreenC)
                            Text("المبلغ ${d.amount.fmt()} • المسدد ${d.paid.fmt()}", fontSize = 12.sp, color = GreenC)
                            Text(if (rem == 0L) "الحالة: مسدد بالكامل ✅" else "المتبقي ${rem.fmt()}", color = GreenC)
                            if (d.note.isNotBlank()) Text(d.note, fontSize = 12.sp)
                            Row {
                                if (rem > 0) TextButton({ pay = d }) { Text("تسديد") }
                                TextButton({ vm.delDebt(d) }) { Text("حذف") }
                            }
                        }
                    }
                }
            }
        }
        Fab({ add = true }, Modifier.align(Alignment.BottomStart))
    }
    if (add) InputDialog(if (tab == 0) "دين جديد لي" else "دين جديد عليّ", listOf("اسم الشخص", "المبلغ بالألف دينار", "ملاحظة"), listOf(false, true, false), { add = false }) {
        val amt = it[1].toIqdThousands()
        if (it[0].isNotBlank() && amt > 0) vm.addDebt(Debt(person = it[0].trim(), amount = amt, owedToMe = tab == 0, note = it[2].trim()))
        add = false
    }
    pay?.let { d ->
        InputDialog("تسديد (متبقي ${(d.amount - d.paid).fmt()})", listOf("المبلغ بالألف دينار"), listOf(true), { pay = null }) {
            val v = it[0].toIqdThousands()
            if (v > 0) vm.pay(d, v)
            pay = null
        }
    }
}

@Composable
fun AccountsScreen(vm: VM) {
    val accs by vm.accounts.collectAsState()
    val txs by vm.txs.collectAsState()
    var add by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 88.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("الحسابات والمحافظ", style = MaterialTheme.typography.headlineSmall) }
            items(accs, key = { it.id }) { a ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 14.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(a.name, fontWeight = FontWeight.Bold); Text(vm.money(bal(a, txs))) }
                        IconButton({ vm.delAccount(a) }) { Icon(Icons.Default.Delete, "حذف") }
                    }
                }
            }
            item { Text("لا يمكن حذف حساب عليه عمليات، أو حذف الحساب الأخير.", fontSize = 12.sp) }
        }
        Fab({ add = true }, Modifier.align(Alignment.BottomStart))
    }
    if (add) InputDialog("حساب جديد", listOf("اسم الحساب (نقداً، مصرف، محفظة…)", "الرصيد الافتتاحي بالألف دينار"), listOf(false, true), { add = false }) {
        if (it[0].isNotBlank()) vm.addAccount(Account(name = it[0].trim(), initial = it[1].toIqdThousands()))
        add = false
    }
}

@Composable
fun GoalsScreen(vm: VM) {
    val goals by vm.goals.collectAsState()
    var add by remember { mutableStateOf(false) }
    var save by remember { mutableStateOf<Goal?>(null) }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 88.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("أهدافي", style = MaterialTheme.typography.headlineSmall) }
            if (goals.isEmpty()) item { Empty("أضف هدفك الأول") }
            items(goals, key = { it.id }) { g ->
                val p = (g.saved.toFloat() / g.target).coerceIn(0f, 1f)
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = GreenC.copy(alpha = 0.06f))) {
                    Column(Modifier.padding(12.dp)) {
                        Text(g.name, fontWeight = FontWeight.Bold, color = GreenC)
                        Text("${g.saved.fmt()} من ${g.target.fmt()} (${(p * 100).toInt()}%)", fontSize = 12.sp, color = GreenC)
                        LinearProgressIndicator(progress = { p }, color = GreenC, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                        if (p >= 1f) Text("🎉 تحقق الهدف!", color = GreenC)
                        Row { TextButton({ save = g }) { Text("إضافة مدخرات") }; TextButton({ vm.delGoal(g) }) { Text("حذف") } }
                    }
                }
            }
        }
        Fab({ add = true }, Modifier.align(Alignment.BottomStart))
    }
    if (add) InputDialog("هدف جديد", listOf("اسم الهدف", "المبلغ المطلوب بالألف دينار"), listOf(false, true), { add = false }) {
        val t = it[1].toIqdThousands()
        if (it[0].isNotBlank() && t > 0) vm.addGoal(Goal(name = it[0].trim(), target = t))
        add = false
    }
    save?.let { g ->
        InputDialog("إضافة مدخرات", listOf("المبلغ بالألف دينار"), listOf(true), { save = null }) {
            val v = it[0].toIqdThousands()
            if (v > 0) vm.saveGoal(g, v)
            save = null
        }
    }
}

@Composable
fun About() {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("محفظتي | Mahfazati", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        Text("Developed by M.Z DIGITAL")
        Text("© 2026 M.Z DIGITAL. All Rights Reserved.", fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Text("بياناتك محفوظة على جهازك فقط.", fontSize = 12.sp)
    }
}
