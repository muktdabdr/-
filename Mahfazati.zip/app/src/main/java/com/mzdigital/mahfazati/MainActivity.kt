package com.mzdigital.mahfazati

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import com.mzdigital.mahfazati.data.AppDatabase
import com.mzdigital.mahfazati.data.Transaction
import com.mzdigital.mahfazati.data.TransactionDao
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

private val Emerald = Color(0xFF087F5B)
private val Pale = Color(0xFFF4F7F5)
private val Ink = Color(0xFF17231E)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val dao = AppDatabase.get(this).transactionDao()
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Emerald, background = Pale, surface = Color.White)) { MahfazatiApp(dao) } }
    }
}

class WalletViewModel(private val dao: TransactionDao) : ViewModel() {
    val transactions = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val balance = dao.observeBalance().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    fun add(amount: Long, type: String, category: String, note: String) = viewModelScope.launch {
        if (amount > 0) dao.insert(Transaction(amount = amount, type = type, category = category, note = note))
    }
    fun delete(item: Transaction) = viewModelScope.launch { dao.delete(item) }
}

@Suppress("UNCHECKED_CAST")
class WalletViewModelFactory(private val dao: TransactionDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T = WalletViewModel(dao) as T
}

@Composable
fun MahfazatiApp(dao: TransactionDao) {
    val vm: WalletViewModel = viewModel(factory = WalletViewModelFactory(dao))
    val transactions by vm.transactions.collectAsState()
    val balance by vm.balance.collectAsState()
    var selected by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var showBalance by remember { mutableStateOf(true) }
    Scaffold(
        containerColor = Pale,
        floatingActionButton = { FloatingActionButton(onClick = { showAdd = true }, containerColor = Emerald, contentColor = Color.White) { Icon(Icons.Default.Add, contentDescription = "إضافة عملية") } },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                val items = listOf("الرئيسية", "العمليات", "الميزانية", "التقارير", "المزيد")
                val icons = listOf(Icons.Default.Home, Icons.Default.ReceiptLong, Icons.Default.Wallet, Icons.Default.Analytics, Icons.Default.MoreHoriz)
                items.forEachIndexed { index, label -> NavigationBarItem(selected = selected == index, onClick = { selected = index }, icon = { Icon(icons[index], null) }, label = { Text(label) }) }
            }
        }
    ) { padding ->
        when (selected) {
            0 -> Dashboard(Modifier.padding(padding), balance, transactions, showBalance) { showBalance = !showBalance }
            1 -> TransactionsScreen(Modifier.padding(padding), transactions, vm::delete)
            2 -> SimpleInfoScreen(Modifier.padding(padding), "الميزانية", "ابدأ بتسجيل عملياتك المالية لبناء ميزانيات دقيقة بناءً على إنفاقك الفعلي.")
            3 -> SimpleInfoScreen(Modifier.padding(padding), "التقارير", "ستظهر تحليلات الدخل والمصروفات بعد تسجيل عملياتك.")
            else -> SimpleInfoScreen(Modifier.padding(padding), "المزيد", "محفظتي | Mahfazati\nتطوير M.Z DIGITAL\nالإصدار 1.0.0")
        }
    }
    if (showAdd) AddTransactionDialog(onDismiss = { showAdd = false }, onSave = { amount, type, category, note -> vm.add(amount, type, category, note); showAdd = false })
}

@Composable
fun Dashboard(modifier: Modifier, balance: Long, transactions: List<Transaction>, showBalance: Boolean, toggleBalance: () -> Unit) {
    val income = transactions.filter { it.type == "دخل" }.sumOf { it.amount }
    val expense = transactions.filter { it.type == "مصروف" }.sumOf { it.amount }
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 28.dp, bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text("مرحباً بك في محفظتي", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
            Text("إدارة أموالك أصبحت أبسط", color = Color.Gray)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Emerald), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("إجمالي الرصيد", color = Color.White.copy(alpha = .85f))
                        Text(if (showBalance) "إخفاء" else "إظهار", color = Color.White, modifier = Modifier.clickable { toggleBalance() })
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(if (showBalance) money(balance) else "•••••• د.ع", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text("الدينار العراقي", color = Color.White.copy(alpha = .8f))
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SummaryCard("الدخل المسجل", income, Color(0xFF16865F), Modifier.weight(1f))
                SummaryCard("المصروفات المسجلة", expense, Color(0xFFD65B5B), Modifier.weight(1f))
            }
        }
        item { Text("آخر العمليات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Ink) }
        if (transactions.isEmpty()) item { EmptyState() } else items(transactions.take(5), key = { it.id }) { TransactionRow(it) }
    }
}

@Composable
fun SummaryCard(title: String, amount: Long, color: Color, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Text(money(amount), color = color, fontWeight = FontWeight.Bold)
            Text("د.ع", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun TransactionsScreen(modifier: Modifier, transactions: List<Transaction>, onDelete: (Transaction) -> Unit) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("سجل العمليات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        if (transactions.isEmpty()) EmptyState() else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(transactions, key = { it.id }) { item ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { TransactionRow(item) }
                    TextButton(onClick = { onDelete(item) }) { Text("حذف", color = Color(0xFFD65B5B)) }
                }
            }
        }
    }
}

@Composable
fun TransactionRow(item: Transaction) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(if (item.type == "دخل") Color(0xFFE5F5ED) else Color(0xFFFFEEEE), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Text(if (item.type == "دخل") "+" else "−", color = if (item.type == "دخل") Emerald else Color(0xFFD65B5B), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.category, fontWeight = FontWeight.SemiBold, color = Ink)
                if (item.note.isNotBlank()) Text(item.note, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
            Text("${if (item.type == "دخل") "+" else "−"}${money(item.amount)}", color = if (item.type == "دخل") Emerald else Color(0xFFD65B5B), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AddTransactionDialog(onDismiss: () -> Unit, onSave: (Long, String, String, String) -> Unit) {
    var type by remember { mutableStateOf("مصروف") }
    var amountText by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("الطعام والشراب") }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    val categories = if (type == "دخل") listOf("الراتب", "العمل الإضافي", "التجارة", "الهدايا", "المشاريع", "أخرى") else listOf("الطعام والشراب", "النقل والمواصلات", "التسوق", "الفواتير", "الإنترنت والاتصالات", "الصحة", "التعليم", "المنزل", "الترفيه", "أخرى")
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة عملية مالية") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = type == "مصروف", onClick = { type = "مصروف"; category = "الطعام والشراب" }, label = { Text("مصروف") })
                FilterChip(selected = type == "دخل", onClick = { type = "دخل"; category = "الراتب" }, label = { Text("دخل") })
            }
            OutlinedTextField(value = amountText, onValueChange = { amountText = it.filter(Char::isDigit); error = false }, label = { Text("المبلغ بالدينار العراقي") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            Text("التصنيف", fontWeight = FontWeight.SemiBold)
            Column(Modifier.heightIn(max = 150.dp)) {
                categories.chunked(2).forEach { pair -> Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { pair.forEach { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) }) } } }
            }
            OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("ملاحظة (اختياري)") }, singleLine = true)
            if (error) Text("أدخل مبلغاً صحيحاً أكبر من صفر", color = MaterialTheme.colorScheme.error)
        }
    }, confirmButton = { TextButton(onClick = { val amount = amountText.toLongOrNull(); if (amount == null || amount <= 0) error = true else onSave(amount, type, category, note.trim()) }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun EmptyState() {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Wallet, null, tint = Emerald, modifier = Modifier.size(36.dp))
            Spacer(Modifier.height(8.dp))
            Text("لا توجد عمليات حتى الآن", fontWeight = FontWeight.SemiBold)
            Text("اضغط زر + لإضافة أول عملية مالية", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun SimpleInfoScreen(modifier: Modifier, title: String, description: String) {
    Column(modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) { Text(description, Modifier.padding(20.dp), color = Color.DarkGray) }
    }
}

fun money(value: Long): String = NumberFormat.getIntegerInstance(Locale("ar", "IQ")).format(value)
