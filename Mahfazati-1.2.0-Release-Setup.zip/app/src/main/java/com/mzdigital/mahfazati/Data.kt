package com.mzdigital.mahfazati

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity data class Account(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val initial: Long = 0)
@Entity data class Tx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, val amount: Long, val category: String,
    val accountId: Long, val toAccountId: Long? = null,
    val date: Long, val note: String = ""
)
@Entity data class Debt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val person: String, val amount: Long, val paid: Long = 0,
    val owedToMe: Boolean, val note: String = ""
)
@Entity data class Goal(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val target: Long, val saved: Long = 0)
@Entity data class Budget(@PrimaryKey val category: String, val cap: Long)

@Dao interface AppDao {
    @Query("SELECT * FROM Account") fun accounts(): Flow<List<Account>>
    @Query("SELECT COUNT(*) FROM Account") suspend fun accountCount(): Int
    @Insert suspend fun addAccount(a: Account)
    @Delete suspend fun delAccount(a: Account)
    @Query("SELECT * FROM Tx ORDER BY date DESC, id DESC") fun txs(): Flow<List<Tx>>
    @Insert suspend fun addTx(t: Tx)
    @Delete suspend fun delTx(t: Tx)
    @Query("SELECT * FROM Debt ORDER BY id DESC") fun debts(): Flow<List<Debt>>
    @Insert suspend fun addDebt(d: Debt)
    @Update suspend fun upDebt(d: Debt)
    @Delete suspend fun delDebt(d: Debt)
    @Query("SELECT * FROM Goal ORDER BY id DESC") fun goals(): Flow<List<Goal>>
    @Insert suspend fun addGoal(g: Goal)
    @Update suspend fun upGoal(g: Goal)
    @Delete suspend fun delGoal(g: Goal)
    @Query("SELECT * FROM Budget") fun budgets(): Flow<List<Budget>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun setBudget(b: Budget)
    @Delete suspend fun delBudget(b: Budget)
}

@Database(entities = [Account::class, Tx::class, Debt::class, Goal::class, Budget::class], version = 1, exportSchema = false)
abstract class DB : RoomDatabase() { abstract fun dao(): AppDao }
