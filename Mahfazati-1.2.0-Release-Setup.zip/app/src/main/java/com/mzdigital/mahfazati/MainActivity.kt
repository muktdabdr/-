package com.mzdigital.mahfazati

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel

val Emerald = Color(0xFF0B6E4F)
val Mint = Color(0xFF3DDC97)
val GreenC = Color(0xFF1E9E63)
val RedC = Color(0xFFD64545)
val WarnC = Color(0xFFF29F05)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark = isSystemInDarkTheme()
            val cs = if (dark) darkColorScheme(primary = Mint, onPrimary = Color.Black, background = Color(0xFF101412), surface = Color(0xFF181D1B), surfaceVariant = Color(0xFF232A27))
            else lightColorScheme(primary = Emerald, background = Color(0xFFF4F6F5), surface = Color.White, surfaceVariant = Color(0xFFE3EBE7))
            MaterialTheme(colorScheme = cs) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App(viewModel()) }
                }
            }
        }
    }
}
