# محفظتي | Mahfazati — Release 1.2.0

تطبيق إدارة مالية شخصية من M.Z DIGITAL، مبني باستخدام Kotlin وJetpack Compose وRoom وDataStore.

## متطلبات البناء
- JDK 17
- Android Gradle Plugin 8.10.1
- Gradle 8.11.1
- Android SDK Platform 36
- Android Build Tools 35.0.0

## نواتج الإصدار
- Google Play: `app/build/outputs/bundle/release/app-release.aab`
- التوزيع المباشر: `app/build/outputs/apk/release/app-release.apk`

## إعداد توقيع Release عبر GitHub Actions
لا ترفع ملف keystore أو كلمات المرور إلى المستودع. أنشئ مفتاح توقيع دائم واحتفظ بنسخة احتياطية آمنة منه. أضف القيم التالية في GitHub Repository → Settings → Secrets and variables → Actions:

- `MAHFAZATI_KEYSTORE_BASE64`: محتوى ملف keystore بعد تحويله إلى Base64.
- `MAHFAZATI_STORE_PASSWORD`: كلمة مرور ملف keystore.
- `MAHFAZATI_KEY_ALIAS`: اسم المفتاح داخل keystore.
- `MAHFAZATI_KEY_PASSWORD`: كلمة مرور المفتاح.

### إنشاء مفتاح التوقيع من هاتف Android عبر Termux
إذا لم يتوفر لديك حاسوب، يمكنك استخدام Termux من مصدره الرسمي، ثم تنفيذ:

```bash
pkg update
pkg install openjdk-17 coreutils
keytool -genkeypair -v -keystore mahfazati-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias mahfazati
base64 -w 0 mahfazati-release.jks
```

أثناء إنشاء المفتاح، أدخل كلمة مرور قوية واحفظها في مكان آمن. سيظهر سطر Base64 طويل؛ انسخه كاملاً وضعه في السر `MAHFAZATI_KEYSTORE_BASE64`. أدخل كلمة مرور ملف المفتاح في `MAHFAZATI_STORE_PASSWORD`، واسم المفتاح `mahfazati` في `MAHFAZATI_KEY_ALIAS`، وكلمة مرور المفتاح في `MAHFAZATI_KEY_PASSWORD`. إذا استخدمت كلمة المرور نفسها للملف والمفتاح، أدخلها في السرّين كليهما.

لا تشارك ملف keystore أو كلمات مروره. احتفظ بها؛ يجب استخدام المفتاح نفسه لكل تحديث لاحق لهذا التطبيق. لا تنشئ مفتاحاً جديداً عند إصدار تحديث.

بعد إضافة الأسرار، افتح تبويب Actions وشغّل `Mahfazati Signed Release` عبر Run workflow. سينتج ملف AAB لرفع Google Play وملف APK للتوزيع المباشر. كما يمكن إنشاء GitHub Release بإضافة Tag مثل `v1.2.0` ودفعه إلى المستودع.

## إعدادات التطبيق
- Application ID: `com.mzdigital.mahfazati`
- Version Name: `1.2.0`
- Version Code: `2`
- minSdk: `26`
- targetSdk / compileSdk: `36`

## ملاحظة
هذا المشروع مُعدّ لإنتاج نسخ Release موقّعة عبر GitHub Actions بعد إعداد أسرار التوقيع. يجب إتمام بناء CI واختبار التطبيق على جهاز فعلي قبل رفعه إلى المتجر.
